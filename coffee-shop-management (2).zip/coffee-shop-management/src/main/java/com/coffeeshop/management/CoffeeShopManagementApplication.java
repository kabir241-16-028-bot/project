package com.coffeeshop.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import com.coffeeshop.management.model.Category;
import com.coffeeshop.management.model.Product;
import com.coffeeshop.management.repository.CategoryRepository;
import com.coffeeshop.management.repository.ProductRepository;

import java.math.BigDecimal;

@SpringBootApplication
public class CoffeeShopManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoffeeShopManagementApplication.class, args);
    }

    // Loads a bit of sample data automatically so the app is useful right after start
    @Bean
    CommandLineRunner initData(CategoryRepository categoryRepository, ProductRepository productRepository) {
        return args -> {
            if (categoryRepository.count() == 0) {
                Category hotCoffee = categoryRepository.save(new Category(null, "Hot Coffee"));
                Category coldCoffee = categoryRepository.save(new Category(null, "Cold Coffee"));
                Category pastry = categoryRepository.save(new Category(null, "Pastry"));

                productRepository.save(new Product(null, "Espresso", new BigDecimal("120.00"), 50, hotCoffee));
                productRepository.save(new Product(null, "Cappuccino", new BigDecimal("150.00"), 40, hotCoffee));
                productRepository.save(new Product(null, "Latte", new BigDecimal("160.00"), 40, hotCoffee));
                productRepository.save(new Product(null, "Cold Brew", new BigDecimal("180.00"), 30, coldCoffee));
                productRepository.save(new Product(null, "Iced Mocha", new BigDecimal("190.00"), 25, coldCoffee));
                productRepository.save(new Product(null, "Croissant", new BigDecimal("90.00"), 20, pastry));
                productRepository.save(new Product(null, "Muffin", new BigDecimal("80.00"), 20, pastry));
            }
        };
    }
}
