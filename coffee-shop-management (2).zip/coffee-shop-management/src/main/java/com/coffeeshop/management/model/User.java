package com.coffeeshop.management.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Username is required")
    @Column(nullable = false, unique = true)
    private String username;

    // Stores a BCrypt hash, never the raw password
    @NotBlank(message = "Password is required")
    @Column(nullable = false)
    private String password;

    private String fullName;

    private String email;

    @Column(nullable = false)
    private String role = "STAFF";
}
