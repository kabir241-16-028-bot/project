package com.coffeeshop.management.repository;

import com.coffeeshop.management.model.Discount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DiscountRepository extends JpaRepository<Discount, Long> {
}
