package com.coffeeshop.management.repository;

import com.coffeeshop.management.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}
