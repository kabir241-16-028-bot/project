package com.coffeeshop.management.repository;

import com.coffeeshop.management.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewRepository extends JpaRepository<Review, Long> {
}
